import java.util.ArrayList;
import java.util.List;

public class ArrayList {
     public static List<Lesson> tumDersler = new ArrayList<>();
     
}

