import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class MenuForm {
    public static void main(String[] args) {

        // Ana pencereyi olusturma
        JFrame frame = new JFrame("Ana Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JButton btnDersKayit = new JButton("Ders Kayıt Formu");
        btnDersKayit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ders Kayıt Formunu aç
                new LessonForm(); // DersKayitFormu sınıfınızın nesnesini oluşturur ve gösterir
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Kenar boşlukları
        frame.add(btnDersKayit, gbc);

        // Ögrenci Kayit Formu butonu
        JButton btnOgrenciKayit = new JButton("Öğrenci Kayıt Formu");
        btnOgrenciKayit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Öğrenci Kayıt Formunu aç
                new StudentForm();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = -5;
        gbc.insets = new Insets(10, 10, 10, 10); // Kenar boşlukları
        frame.add(btnOgrenciKayit, gbc);

        // Pencereyi boyutlandirma ve gorunur yapma
        frame.pack(); // Icerik boyutuna göre pencereyi boyutlandırır
        frame.setLocationRelativeTo(null); // Pencereyi ekranda ortalar
        frame.setVisible(true);
    }
}